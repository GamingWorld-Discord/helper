################################################
#  You have been infected by AnnoyMe?          #
#  AnnoyMe isn't a trojan, well like:          #
#  Not a trojan but an annyoning virus         #
#  To stop it just click the "OffAnnoyMe" file #
################################################

*************************************
How do i run it?
*************************************
1. Export all the files to the desktop
2. Run the "Helper.cmd", if it dont run in the .rar

*************************************
What happend to my pc, it will die?
*************************************
Sure not!, this trojan just try to annoy you, to test user annoyment.
The main virus is hidden. So you can't just delete it. You can delete the whole .rar file

************************************
I run the app, i can't close, help!
************************************
Don't worry. Search up for "Task Manager" and turn off the app with the virus icon on the taskbar.

Note: Developers of AnnoyMe don't take any responsibility of your pc management skills.
If you can't disable the virus / trojan. Just ignore it or restart your pc.